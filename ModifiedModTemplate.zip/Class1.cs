﻿using HutongGames.PlayMaker;
using HutongGames.PlayMaker.Actions;
using MSCLoader;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using $safeprojectname$Helper;

namespace $safeprojectname$  
{
    public class $safeprojectname$ : Mod
    {
        public override string ID => "$safeprojectname$";
        public override string Name => "$projectname$";
        public override string Author => "NAME";
        public override string Version => "1.0";
        public override bool UseAssetsFolder => false;

        public override void OnLoad()
        {
        }
    }
}